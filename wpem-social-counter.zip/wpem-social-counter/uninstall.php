<?php

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit();
}


$options = array();

foreach ( $options as $option ) {
	//delete_option( $option ); uncomment when you have value in options
}

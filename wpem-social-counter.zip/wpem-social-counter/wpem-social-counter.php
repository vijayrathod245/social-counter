<?php
/**
Plugin Name: WPEM Social Counter
Plugin URI: https://www.wp-eventmanager.com
Description: Social Counter Plugin.
Author: WP Event Manager
Author URI: https://www.wp-eventmanager.com
Text Domain: wpem-social-counter
Domain Path: /languages
Version: 1.0.0
Since: 1.0.0
Requires WordPress Version at least: 4.1
Copyright: 2022 Social Counter
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
**/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	
	exit;
}

include_once(ABSPATH.'wp-admin/includes/plugin.php');

/**
 * WP_Social_Counter class.
 */
class WP_Social_Counter {

	/**
	 * The single instance of the class.
	 *
	 * @var self
	 * @since 1.0.0
	 */
	private static $_instance = null;

	/**
	 * Main WP Social Counter Instance.
	 *
	 * Ensures only one instance of WP Event Manager is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 * @static
	 * @see WP_Social_Counter()
	 * @return self Main instance.
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * Constructor - get the plugin hooked in and ready
	 */
	public function __construct() {

		//if wp event manager not active return from the plugin
		/*if ( !is_plugin_active( 'wp-event-manager/wp-event-manager.php') )
			return;*/

		// Define constants
		define( 'WPEM_SOCIAL_COUNTER_VERSION', '1.0.4' );
		define( 'WPEM_SOCIAL_COUNTER_PLUGIN_DIR', untrailingslashit( plugin_dir_path( __FILE__ ) ) );
		define( 'WPEM_SOCIAL_COUNTER_PLUGIN_URL', untrailingslashit( plugins_url( basename( plugin_dir_path( __FILE__ ) ), basename( __FILE__ ) ) ) );
		
		include( 'wpem-social-counter-functions.php' );		
		include( 'wpem-social-counter-template.php' );
		// Includes
		include( 'includes/wpem-social-counter-post-types.php' );
		//post type
		//include('includes/wpem-pluginslug-post-types.php');
		//shortcodes
		include( 'shortcodes/wpem-pluginslug-shortcodes.php' );
		include( 'shortcodes/wpem-social-counter-shortcodes.php' );
		//include( 'includes/wpem-social-counter-list-shortcode.php' );
		
		//external 
		include('external/external.php');

		// Init classes
		$this->post_types = new WP_SocialCounter_Post_Types();

		// Activation / deactivation - works with symlinks
		register_activation_hook( basename( dirname( __FILE__ ) ) . '/' . basename( __FILE__ ), array( $this, 'activate' ) );
		register_deactivation_hook( basename( dirname( __FILE__ ) ) . '/' . basename( __FILE__ ), array( $this, 'deactivate' ) );
		include( 'includes/wpem-social-counter-install.php' );
		// Actions
		add_action( 'after_setup_theme', array( $this, 'load_plugin_textdomain' ) );

		add_action( 'admin_init', array( $this, 'updater' ) );

		if(is_admin()){
			include('admin/wpem-social-counter-admin.php');
		}

		//WP_Social_Counter_Shortcodes::display_social_counter_list();
		//add_shortcode( 'social-counter-list', array( $this, 'sc_shortcode' ) ); //adds a shortcode
		//add_shortcode( 'social-counter-list', array( $this, 'display_social_counter_all_list' ) );
		//add_shortcode( 'social-counter-fb', array( $this, 'fbLikeCount' ) );
		//WP_Social_Counter_List_Shortcode::social_counter_list_shortcode();
		//add_shortcode( 'dotiavatar', array( $this, 'bartag_func' ) );
		//add_shortcode( 'fan-count-list', array( $this, 'fbLikeCount_list' ) );
	}
	/*function fbLikeCount_list($id,$appid,$appsecret){
			$id = 2536455826484333;
			$appid = 3214473602154291;
			$appsecret = '6ab1777998b4ebb003888c8f0762ee18';
			//$access_token = 'EAAtriZCUyPzMBAC1i6BXmEqN75JAklUFRUFyN9Bng9ZAjlz8NHamQ31rgXGNY0qgvD1GzAGHxal9hlEyyCz4CIzaMPTeSXhOiIUrb6Nx7WJ4F1ngSq0ZBShGuWtyIJBZBtGd9TuGYUF7yOOa7voKFWzjwLeuwoZB0CZCq5GPEVKjvPshJUB8zFppH1O8NGtKTLxJyoVUytgwZDZD';
		   $json_url_count ='https://graph.facebook.com/2536455826484333/accounts?access_token=EAAtriZCUyPzMBAPLjgZCnohp6BzOEEeiW0snFJCHgN8EGC7KYK2PWeekrjK9IuDYipy3RrNtOPuW44DraulKoZAJpvfRieqWb8Yz9PYCX8gdbM7087nhVkWCJ2GkyLVALmcLE9bliMY0AEoWaiLko9qGAtkdc3qZCK43cXYIHCm85X5VfYJp&fields=name,followers_count';
		   //$json_url ='https://graph.facebook.com/'.$id.'?access_token='.$access_token.'&fields=name,fan_count';
		   $json_count = file_get_contents($json_url_count);
		   $json_output_count = json_decode($json_count);
		   //echo '<pre>';
		   //print_r($json_output_count);die;
		   
	}*/	
	/*function display_social_counter_all_list(){
		$json_url ='https://graph.facebook.com/2536455826484333/accounts?access_token=EAAtriZCUyPzMBAPLjgZCnohp6BzOEEeiW0snFJCHgN8EGC7KYK2PWeekrjK9IuDYipy3RrNtOPuW44DraulKoZAJpvfRieqWb8Yz9PYCX8gdbM7087nhVkWCJ2GkyLVALmcLE9bliMY0AEoWaiLko9qGAtkdc3qZCK43cXYIHCm85X5VfYJp&fields=name,followers_count,groups';
		  	$json = file_get_contents($json_url);
		  	$json_output = json_decode($json);
		  	
		  	echo '<pre>';
		  	print_r($json_output);die;
		  	foreach($json_output->data as $val){
		  		?>
		  		<div><?php echo $val->name; ?>: <b><?php echo $val->followers_count; ?></b></div>
		  		<?php
		  	}
	}*/
		/*function fbLikeCount($atts){
		  	$json_url_one ='https://graph.facebook.com/2536455826484333/accounts?access_token=EAAtriZCUyPzMBAPLjgZCnohp6BzOEEeiW0snFJCHgN8EGC7KYK2PWeekrjK9IuDYipy3RrNtOPuW44DraulKoZAJpvfRieqWb8Yz9PYCX8gdbM7087nhVkWCJ2GkyLVALmcLE9bliMY0AEoWaiLko9qGAtkdc3qZCK43cXYIHCm85X5VfYJp&fields=name,followers_count';
		  	$json_one = file_get_contents($json_url_one);
		  	$json_output_one = json_decode($json_one);
		  	//echo '<pre>';
		  	//print_r($json_output_one);die;
		  	$attributes = shortcode_atts(
	        array(
	            'id' => '',
	        ), $atts );

	        // $attributes['id'] is now the passed-in ID

	       // $html_out = '';

				foreach($json_output_one->data as $val_id){
						$page_name = $val_id->name;
						$page_followers = $val_id->followers_count;
				}
		  	//echo '<pre>';
		  	//print_r($json_output);die;?> </br> 
		   <div><?php echo $page_name; ?>: <b><?php echo $page_followers; ?></b></div>
		<?php	
	
		//return $html_out;	  	
		}*/
		//echo fbLikeCount('coregenie','___APPID___','___APPSECRET___');

	

	/**
     * activate function.
     *
     * @access public
     * @param 
     * @return 
     * @since 1.0.0
     */
	public function activate() {
		//installation process after activating
		//WP_Social_Counter_Install::install();
	}

	/**
     * deactivate function.
     *
     * @access public
     * @param 
     * @return 
     * @since 1.0.0
     */
	public function deactivate() {
		//WP_Social_Counter_Install::uninstall();
	}

	/**
     * updater function.
     *
     * @access public
     * @param 
     * @return 
     * @since 1.0.0
     */
	public function updater() {
		/*if ( version_compare( WPEM_PLUGINSLUG_VERSION, get_option( 'wpem_pluginslug_version' ), '>' ) ) {

			//WPEM_Pluginslug_Install::update();
			//flush_rewrite_rules();
		}*/
	}

	/**
	* load_plugin_textdomain function.
	*
	* @access public
	* @param
	* @return 
	* @since 1.0.0
	*/
	public function load_plugin_textdomain() {

		$domain = 'wpem-social-counter';   

        $locale = apply_filters('plugin_locale', get_locale(), $domain);

		load_textdomain( $domain, WP_LANG_DIR . "/wpem-social-counter/".$domain."-" .$locale. ".mo" );

		load_plugin_textdomain($domain, false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
	}	
}

new WP_Social_Counter();

<?php
/**
 * WP_Social_Counter_Api_Key class.
 */
class WP_Social_Counter_Api_Key {

    /**
     * add_facebook_api_key function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */

    public static function add_social_api_key(){
        if (isset($_POST['submit'])) {
            $api_key = sanitize_text_field( $_POST['fbappkey'] );
            $api_secret_key = sanitize_text_field( $_POST['fbsecretkey'] );

            if ( !empty($api_key) && !empty($api_secret_key) ) {
                update_option('fbappkey', $api_key);
                update_option('fbsecretkey', $api_secret_key);
            } else {
                add_option('fbappkey', $api_key);
                add_option('fbsecretkey', $api_secret_key);
            }
        }
    }

    /**
     * add_instagram_api_key function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public static function add_instagram_api_key(){
        if (isset($_POST['submit'])) {
            $instagram_appKey = sanitize_text_field( $_POST['instagram_appKey'] );
            $instagram_access_token = sanitize_text_field( $_POST['instagram_access_token'] );
            //echo '<pre>';
            //print_r($instagram_appKey);die;
            if ( !empty($instagram_appKey) && !empty($instagram_access_token) ) {
                update_option('instagram_appKey', $instagram_appKey);
                update_option('instagram_access_token', $instagram_access_token);
            } else {
                add_option('instagram_appKey', $instagram_appKey);
                add_option('instagram_access_token', $instagram_access_token);
            }
        }
    }

    /**
     * add_linkedin_api_key function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public static function add_linkedin_api_key(){
        if (isset($_POST['submit'])) {
            $linkedin_appKey = sanitize_text_field( $_POST['linkedin_appKey'] );
            $linkedin_access_token = sanitize_text_field( $_POST['linkedin_access_token'] );
            //echo '<pre>';
            //print_r($instagram_appKey);die;
            if ( !empty($linkedin_appKey) && !empty($linkedin_access_token) ) {
                update_option('linkedin_appKey', $linkedin_appKey);
                update_option('linkedin_access_token', $linkedin_access_token);
            } else {
                add_option('linkedin_appKey', $linkedin_appKey);
                add_option('linkedin_access_token', $linkedin_access_token);
            }
        }
    }
}
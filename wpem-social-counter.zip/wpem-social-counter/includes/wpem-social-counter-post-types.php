<?php
/**
 * WP_Event_Manager_Registrations_Post_Types class.
 */
class WP_SocialCounter_Post_Types {

	/**
	 * Constructor
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'register_post_types' ), 20 );
	}

	/**
	 * register_post_types function.
	 */
	public function register_post_types() {
		if ( post_type_exists( "social_counter" ) ) {
			return;
		}

		$plural   = __( 'Social Counter', 'social-counter' );
		$singular = __( 'Social Counter', 'social-counter' );

		register_post_type( "social_counter",
			apply_filters( "register_post_type_event_registration", array(
				'labels' => array(
					'name' 					=> $plural,
					'singular_name' 		=> $singular,
					'menu_name'             => $plural,
					'all_items'             => sprintf( __( 'All %s', 'social-counter' ), $plural ),
					'add_new' 				=> __( 'Add New', 'social-counter' ),
					'add_new_item' 			=> sprintf( __( 'Add %s', 'social-counter' ), $singular ),
					'edit' 					=> __( 'Edit', 'social-counter' ),
					'edit_item' 			=> sprintf( __( 'Edit %s', 'social-counter' ), $singular ),
					'new_item' 				=> sprintf( __( 'New %s', 'social-counter' ), $singular ),
					'view' 					=> sprintf( __( 'View %s', 'social-counter' ), $singular ),
					'view_item' 			=> sprintf( __( 'View %s', 'social-counter' ), $singular ),
					'search_items' 			=> sprintf( __( 'Search %s', 'social-counter' ), $plural ),
					'not_found' 			=> sprintf( __( 'No %s found', 'social-counter' ), $plural ),
					'not_found_in_trash' 	=> sprintf( __( 'No %s found in trash', 'social-counter' ), $plural ),
					'parent' 				=> sprintf( __( 'Parent %s', 'social-counter' ), $singular )
				),
				'description'         => __( 'This is where you can edit and view registrations.', 'social-counter' ),
				'public'              => false,
				'show_ui'             => true,
				'capability_type'     => 'event_registration',
				'map_meta_cap'        => true,
				'publicly_queryable'  => false,
				'exclude_from_search' => true,
				'hierarchical'        => false,
				'rewrite'             => false,
				'query_var'           => false,
				'supports'            => array( 'title', 'custom-fields', 'editor' ),
				'has_archive'         => false,
				'show_in_nav_menus'   => false
			) )
		);
	}
	
}

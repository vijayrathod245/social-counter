<?php
/**
 * WP_Social_Counter_Api_Key class.
 */
class WP_Social_Counter_Instagram {

    /**
     * add_social_api_key function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */

    public static function add_social_instagram_api(){
        if (isset($_POST['submit'])) {
            $instagram_appKey = sanitize_text_field( $_POST['instagram_appKey'] );
            $instagram_access_token = sanitize_text_field( $_POST['instagram_access_token'] );
            
            /*if ( !empty($api_key) && !empty($api_secret_key) ) {
                update_option('fbappkey', $api_key);
                update_option('fbsecretkey', $api_secret_key);
            } else {
                add_option('fbappkey', $api_key);
                add_option('fbsecretkey', $api_secret_key);
            }*/
            
            $social_counter_data = array(
                 'instagram_appKey' => $instagram_appKey,
                 'instagram_access_token' => $instagram_access_token
            );
            //echo '<pre>';
            //print_r($social_counter_data);die;
            // Add into the option.
            add_option( 'instagram_info', $social_counter_data );
        }
    }
}
<?php
/**
 * WPEM_Social_Counter_List class.
 */
class WPEM_Social_Counter_List{
	/**
	 * social counter list function.
	 * get social counter list
	 * @access public
	 * @param 
	 * @return array
	 * @since 1.0.0
	 */
	public function social_counter_list() {
		get_event_manager_template( 'social-counter-list.php', WPEM_SOCIAL_COUNTER_PLUGIN_DIR . '/templates/admin/');
	}
}

new WPEM_Social_Counter_List();
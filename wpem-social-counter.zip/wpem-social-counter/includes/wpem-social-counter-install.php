<?php 
/**
 * WP_Social_Counter_Install class.
 */

class WP_Social_Counter_Install {

	/**
     * install function.
     *
     * @access public static
     * @param 
     * @return 
     * @since 1.0
     */

	public static function install() {
		// Initialize DB Tables
		// WP Globals
		global $table_prefix, $wpdb;


		// Social Counter Table
		$socialcounterTable = $table_prefix . 'social_counter';

		// Create Social Counter Table if not exist
		if ($wpdb->get_var("show tables like '$socialcounterTable'") != $socialcounterTable) {

			// Query - Create Table
			$sql = "CREATE TABLE `$socialcounterTable` (";
			$sql .= " `id` int(11) NOT NULL auto_increment, ";
			$sql .= " `apikey` varchar(500) NOT NULL, ";
			$sql .= " `secretkey` varchar(500) NOT NULL, ";
			$sql .= " PRIMARY KEY `id` (`id`) ";
			$sql .= ") ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;";

			// Include Upgrade Script
			require_once(ABSPATH . '/wp-admin/includes/upgrade.php');

			// Create Table
			dbDelta($sql);
		}
	}
	// Callback function to drop table
	public static function uninstall() {
	    global $table_prefix, $wpdb;
	    $table_name = $table_prefix .'social_counter';
	    $sql = "DROP TABLE IF EXISTS $table_name";
	    $wpdb->query($sql);
	    delete_option("devnote_plugin_db_version");
	}
}
<?php
/*
* This file use for settings at admin site for social counter plugin.
*/

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

/**
 * WP_Social_Counter_Settings class.
 */
class WP_Social_Counter_Settings{
	/**
	 * __construct function.
	 *
	 * @access public
	 * @return void
	 */

	public function __construct(){
		$this->settings_group = 'social_counter';
		add_action('admin_init', array($this, 'register_settings'));
		include_once( WPEM_SOCIAL_COUNTER_PLUGIN_DIR . '/includes/wpem-social-counter-add-apikey.php' );
		include_once( WPEM_SOCIAL_COUNTER_PLUGIN_DIR . '/includes/wpem-social-counter-add-instagram.php' );
		//include_once 'wpem-social-counter-apikey.php';
		WP_Social_Counter_Api_Key::add_social_api_key();
		WP_Social_Counter_Api_Key::add_instagram_api_key();
		WP_Social_Counter_Api_Key::add_linkedin_api_key();
		WP_Social_Counter_Instagram::add_social_instagram_api();

	}
	public function init_settings() {
		
		//include_once( WPEM_SOCIAL_COUNTER_PLUGIN_DIR . '/templates/admin/social-counter-list.php' );

		$this->settings = apply_filters(
			'social_counter_settings',
			array(
				'facebook_settings'     => array(

					__('Facebook', 'wpem-social-counter'),

					array(

						array(
							'name'       => 'fbappkey',
							'std'        => '',
							'label'      => __('App Key', 'wpem-social-counter'),
							'desc'   => __('Please go to <a href="https://developers.facebook.com/" target="_blank">https://developers.facebook.com </a> and create an app and get the App ID', 'wpem-social-counter'),
							'type'       => 'input',
							'attributes' => array(),
						),
						array(
							'name'       => 'fbsecretkey',
							'std'        => '',
							'label'      => __('Facebook Access Token', 'wpem-social-counter'),
							'desc'   => __('Please go to <a href="https://developers.facebook.com/" target="_blank">https://developers.facebook.com </a> and create an app and get the Secret Key', 'wpem-social-counter'),
							'type'       => 'input',
							'attributes' => array(),
						),
					),
				),
				'instagram_settings'       => array(

					__('Instagram', 'wpem-social-counter'),

					array(

						array(
							'name'        => 'instagram_appKey',
							'std'         => '',
							'placeholder' => '',
							'label'       => __('Instagram Page ID', 'wpem-social-counter'),
							'desc'        => __('Please go to <a href="https://www.instagram.com/developer/" target="_blank"> https://www.instagram.com/developer/ </a> and create an app and get the App ID', 'wpem-social-counter'),
							'type'        => 'input',
							'attributes'  => array(),
						),
						array(
							'name'       => 'instagram_access_token',
							'std'        => '',
							'label'      => __('Facebook Access Token', 'wpem-social-counter'),
							'desc'   => __('Please go to <a href="https://www.instagram.com/developer/" target="_blank"> https://www.facebook.com/developer/ </a> and create an app and get the Secret Key', 'wpem-social-counter'),
							'type'       => 'input',
							'attributes' => array(),
						),
					),
				),

				'linkedin_settings'       => array(

					__('Linkedin', 'wpem-social-counter'),

					array(

						array(
							'name'        => 'linkedin_appKey',
							'std'         => '',
							'placeholder' => '',
							'label'       => __('lLinkedin Page ID', 'wpem-social-counter'),
							'desc'        => __('Please go to <a href="https://www.linkedin.com/developers" target="_blank"> https://www.linkedin.com/developers </a> and create an app and get the App ID', 'wpem-social-counter'),
							'type'        => 'input',
							'attributes'  => array(),
						),
						array(
							'name'       => 'linkedin_access_token',
							'std'        => '',
							'label'      => __('Linkedin Access Token', 'wpem-social-counter'),
							'desc'   => __('Please go to <a href="https://www.linkedin.com/developers" target="_blank"> https://www.linkedin.com/developers  </a> and create an app and get the Secret Key', 'wpem-social-counter'),
							'type'       => 'input',
							'attributes' => array(),
						),
					),
				),
			)
		);
	}

	/**
	 * register_settings function.
	 *
	 * @access public
	 * @return void
	 */

	public function register_settings()
	{

		$this->init_settings();

		foreach ($this->settings as $section) {

			foreach ($section[1] as $option) {

				if (isset($option['std'])) {

					add_option($option['name'], $option['std']);
				}

				register_setting($this->settings_group, $option['name']);
			}
		}

	}
	/**
	 * output function.
	 *
	 * @access public
	 * @return void
	 */

	public function output()
	{

		$this->init_settings();
		?>
		<div class="wrap event-manager-settings-wrap">

			<h1 class="wp-heading-inline">
				<?php
				esc_attr_e('Settings', 'wpem-social-counter');
				?>
			</h1>

			<div class="wpem-wrap event-manager-settings-wrap">

				<form method="post" name="event-manager-settings-form">

					<?php //settings_fields($this->settings_group); ?>

					<h2 class="nav-tab-wrapper">

						<?php

						foreach ($this->settings as $key => $section) {

							echo '<a href="#settings-' . sanitize_title($key) . '" class="nav-tab">' . esc_html($section[0]) . '</a>';
						}
						?>
					</h2>

					<div class="admin-setting-left">

						<div class="white-background">

							<?php

							if (!empty($_GET['settings-updated'])) {

								flush_rewrite_rules();

								echo '<div class="updated fade event-manager-updated"><p>' . esc_attr__('Settings successfully saved', 'wpem-social-counter') . '</p></div>';
							}

							foreach ($this->settings as $key => $section) {

								echo '<div id="settings-' . sanitize_title($key) . '" class="settings_panel">';

								echo '<table class="form-table">';

								foreach ($section[1] as $option) {

									$placeholder = (!empty($option['placeholder'])) ? 'placeholder="' . $option['placeholder'] . '"' : '';

									$class = !empty($option['class']) ? $option['class'] : '';

									$value = get_option($option['name']);

									$option['type'] = !empty($option['type']) ? $option['type'] : '';

									$attributes = array();

									

									echo '<tr valign="top" class="' . esc_attr($class) . '"><th scope="row"><label for="setting-' . esc_attr($option['name']) . '">' . esc_attr($option['label']) . '</a></th><td>';

									switch ($option['type']) {

										case 'checkbox':
							?>
											<label><input id="setting-<?php echo esc_attr($option['name']); ?>" name="<?php echo esc_attr($option['name']); ?>" type="checkbox" <?php echo implode(' ', $attributes); ?> <?php checked('1', $value); ?> /> <?php echo esc_attr($option['cb_label']); ?></label>
											<?php

											if ($option['desc']) {

												echo ' <p class="description">' . esc_attr($option['desc']) . '</p>';
											}

											break;

						
										case 'input':
											?>
											<input id="setting-<?php echo esc_attr($option['name']); ?>" class="regular-text" type="text" name="<?php echo esc_attr($option['name']); ?>" value="<?php esc_attr_e($value); ?>" <?php echo implode(' ', $attributes); ?> <?php echo $placeholder; ?> />
											<?php

											if ($option['desc']) {

												echo ' <p class="description">' . sprintf(__('%s','wpem-social-counter'),$option['desc']) . '</p>';
											}

											break;

										case 'text':
											?>
											<input id="setting-<?php echo esc_attr($option['name']); ?>" class="regular-text" type="text" name="<?php echo esc_attr($option['name']); ?>" value="<?php esc_attr_e($value); ?>" <?php echo implode(' ', $attributes); ?> <?php echo $placeholder; ?> />
											<?php

											if ($option['desc']) {

												echo ' <p class="description">' . sprintf(__('%s','wpem-social-counter'),$option['desc']) . '</p>';
											}

											break;
										
										case 'button':
											?>
											<button class="button" id="setting-<?php echo esc_attr($option['name']); ?>" class="regular-text" type="button" name="<?php echo esc_attr($option['name']); ?>" <?php echo implode(' ', $attributes); ?> <?php echo esc_attr($placeholder); ?>><?php echo esc_attr($option['cb_label']); ?></button>
										<?php

											if ($option['desc']) {

												echo ' <p class="description">' . sprintf(__('%s','wpem-social-counter'),$option['desc']) . '</p>';
											}

											break;

										default:
											do_action('wp_event_manager_admin_field_' . $option['type'], $option, $attributes, $value, $placeholder);

											break;
									}
									echo '</td></tr>';
								}
								echo '</table></div>';
							}
							?>
						</div> <!-- .white-background- -->
						<p class="submit">
							<input type="submit" class="button-primary" name="submit" id="save-changes" value="<?php esc_attr_e('Save Changes', 'wpem-social-counter'); ?>" />
						</p>
					</div> <!-- .admin-setting-left -->

				</form>
			</div>
		</div>
		<?php
	}
}

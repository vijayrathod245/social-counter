<?php
/**
 * WPEM_Social_Counter_Admin class.
 */
class WPEM_Social_Counter_Admin {

	/**
	 * Constructor - get the plugin hooked in and ready
	 */
	public function __construct() {

		//include 'wpem-social-counter-list.php';
		//include_once( WPEM_SOCIAL_COUNTER_PLUGIN_DIR . '/admin/wpem-social-counter-settings.php' );
		include_once 'wpem-social-counter-settings.php';
		add_action( 'admin_menu', array( $this, 'admin_menu' ), 12 );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ) );

		$this->social_counter_page = new WP_Social_Counter_Settings();
		$this->settings_page = new WP_Social_Counter_Settings();
	}

	/**
	 * admin_menu function.
	 * register menu in admin side
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function admin_menu() {
		global $wpdb;

		//add_submenu_page('edit.php?post_type=social_counter', __('Settings', 'social-counter'), __('Settings', 'social-counter'), 'manage_options', 'social-counter-settings', array($this->social_counter_page, 'output'));

		add_menu_page( 'WPEM Social Counter', 'WPEM Social Counter', 'manage_options', 'social-counter', array($this->social_counter_page, 'output'), 'dashicons-share' );

		add_submenu_page( 'edit.php?post_type=social_counter', __( 'Settings', 'social-counter' ), __( 'Settings', 'social-counter' ), 'manage_options', 'social-counter-settings', array( $this->settings_page, 'output' ) );
	}
	
	/**
	 * admin_enqueue_scripts function.
	 * enqueue style and script for admin
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function admin_enqueue_scripts() {
		wp_enqueue_style( 'admin-social-share', WPEM_SOCIAL_COUNTER_PLUGIN_URL . '/assets/css/admin.css' );
		wp_enqueue_script( 'js-admin-social-share', WPEM_SOCIAL_COUNTER_PLUGIN_URL . '/assets/js/admin-settings.js' );
		//wp_register_script('wp-event-manager-admin-settings', WPEM_SOCIAL_COUNTER_PLUGIN_URL . '/assets/js/admin-settings.min.js', array('jquery'), WPEM_SOCIAL_COUNTER_PLUGIN_URL, true);
	}
}

new WPEM_Social_Counter_Admin();


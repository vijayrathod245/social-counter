<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
/**
 * WP_Social_Counter_Shortcodes class.
 */

class WP_Social_Counter_Shortcodes {

    /**
     * Constructor
     */
	public function __construct() {
        add_shortcode('social_counter_list', array( $this, 'display_social_counter_list') );
        add_shortcode( 'fan-count-list', array( $this, 'fbLikeCount_list' ) );
        add_shortcode( 'social-counter-fb', array( $this, 'fbLikeCount' ) );
        add_shortcode('group-list', array( $this, 'fb_group_list'));
        add_shortcode('instagram-count', array( $this, 'display_instagram_followers'));
        add_shortcode('linkedin-followers', array( $this, 'getCompanyFollowers'));
    }
    /**
     *  It is very simply a plugin that outputs a list of Linkedin followers. 
     *  
     *  This will Linkedin followers.
     */
    public function getCompanyFollowers($company_id=""){
        //if(!$company_id)return false;
        $params['url'] = "https://api.linkedin.com/v1/companies/80848375:(num-followers)";
        $params['method']='get';
        $params['args']['format']='json';
        $result =  $this->makeRequest($params);
        echo '<pre>';
        print_r($result);die;
        return json_decode($result,true);
    }  

    /**
     *  It is very simply a plugin that outputs a list of Instagram followers. 
     *  
     *  This will Instagram followers.
     */

    function display_instagram_followers() {
        $fb_access_token = get_option('instagram_access_token');
        $insta_user_name = get_option('instagram_appKey');
        $insta_url = 'https://graph.facebook.com/v13.0/17841402260203789?fields=business_discovery.username('.$insta_user_name.'){followers_count,media_count}&access_token='.$fb_access_token;
        $insta_list = file_get_contents($insta_url);
        $insat_json = json_decode($insta_list);
        ?>
        <h4>Instagram Followers</h4>
        <?php
        foreach($insat_json as $insta_value){
            echo '<b>'.$insta_value->followers_count.'</b>';
        }
    }
    

    /**
     *  It is very simply a plugin that outputs a list of social counter group. 
     *  
     *  This will social group.
     */

    function fb_group_list() {
        $fb_app_id = get_option('fbappkey');
        $fb_access_token = get_option('fbsecretkey');
        $group_json_url ='https://graph.facebook.com/'.$fb_app_id.'/groups?access_token='.$fb_access_token.'&limit=250&fields=id,name,member_count';
        $group_json = file_get_contents($group_json_url);
        $group_json_output = json_decode($group_json);
        //echo '<pre>';
        //print_r($group_json_url);die;
        echo '<br><h3><b>Group List</b></h3>';
        foreach ($group_json_output->data as $group_list) { 
            return '<div><b>Group Name: </b>'. $group_list->name .'<br/> <b>Total Member: </b>'.$group_list->member_count.'</div>';
        }
    }
        

    /**
     *  It is very simply a plugin that outputs a list of facebook counter list. 
     *  
     *  This will social list.
     */
    public function display_social_counter_list(){

        /*extract( shortcode_atts( array(
            
            'id' => '',

        ), $atts ) );

        

        $args = array(
            'p'           => $id,
        );
        $organizers = new WP_Query( $args );*/
        //echo '<pre>';
        //print_r($organizers);die;
        
        //$fb_app_id = get_option('fbappkey');
        $fb_access_token = get_option('fbsecretkey');
        //echo '<pre>';
        //print_r($fb_access_token);die;
        //$json_url ='https://graph.facebook.com/'.$fb_app_id.'/accounts?access_token='.$fb_access_token.'&fields=id,name,followers_count';
        $json_url ='https://graph.facebook.com/me/accounts?fields=fields=id,name,followers_count&access_token='.$fb_access_token;
       // me/accounts?fields=fields=id,name,followers_count


        /*echo '<pre>';
        print_r($json_url);die;*/
        $json = file_get_contents($json_url);
        $json_output = json_decode($json);
        //echo '<pre>';
        //print_r($json_output);die;
        //if($id){
        echo '<h2><b>Page List</b></h2>';
            foreach($json_output->data as $val){ ?>
                <div><span><b>Page Name:</b> </span><?php echo $val->name; ?>:<br /> <b>Total Followers: </b><?php echo $val->followers_count; ?></div><br/   ><?php
            }
        //}   
    }
    function fbLikeCount_list(){
        //$id = 2536455826484333;
        $appid = get_option('fbappkey');
        $access_token = get_option('fbsecretkey');
        //$appsecret = '6ab1777998b4ebb003888c8f0762ee18';
        //$access_token = 'EAAtriZCUyPzMBAC1i6BXmEqN75JAklUFRUFyN9Bng9ZAjlz8NHamQ31rgXGNY0qgvD1GzAGHxal9hlEyyCz4CIzaMPTeSXhOiIUrb6Nx7WJ4F1ngSq0ZBShGuWtyIJBZBtGd9TuGYUF7yOOa7voKFWzjwLeuwoZB0CZCq5GPEVKjvPshJUB8zFppH1O8NGtKTLxJyoVUytgwZDZD';
        $json_url_count ='https://graph.facebook.com/'.$appid.'/accounts?access_token='.$access_token.'&fields=name,followers_count';
        //$json_url ='https://graph.facebook.com/'.$id.'?access_token='.$access_token.'&fields=name,fan_count';
        $json_count = file_get_contents($json_url_count);
        $json_output_count = json_decode($json_count);
        //echo '<pre>';
        //print_r($json_output_count);die;
           
    }
}

new WP_Social_Counter_Shortcodes(); ?>

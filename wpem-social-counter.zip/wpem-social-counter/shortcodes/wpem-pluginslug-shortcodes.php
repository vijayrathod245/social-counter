<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
/**
 * WPEM_Pluginslug_Shortcodes class.
 */

class WPEM_Pluginslug_Shortcodes {

	public function __construct() {}
}

new WPEM_Pluginslug_Shortcodes(); ?>

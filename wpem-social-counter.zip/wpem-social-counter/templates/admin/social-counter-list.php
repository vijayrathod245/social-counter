<div class="wpem-wrap event-manager-settings-wrap">
	<div class="social-list-main">
		<h1>Social Share List</h1>
		<div class="type-field-info">
			<h3>Facebook</h3>
			<div class="social-share social-linkedin">
				<div class="label-title"><label>App ID</label></div>
				<div class="input-info"><input type="text" name="social[linkedin][company]" id="social[linkedin][company]" /></div>
			</div>
			<div class="social-share social-linkedin">
				<div class="label-title"><label>App Secret</label></div>
				<div class="input-info"><input type="text" name="social[linkedin][company]" id="social[linkedin][company]" /></div>
			</div>
			<div class="social-share social-linkedin">
				<input type="submit" value="Submit" name="submit" class="button-large button-primary" />
			</div>
		</div>
	</div>
</div>